from django.contrib import admin
from .models import List

admin.site.register(List)